# OTC Resource Monitor

FunctionGraph-Function für automatische Resource-Reports per E-Mail.

## Features
- Listet alle Resources: ECS, RDS, OBS, EVS, VPC, Subnets
- HTML-Report per E-Mail
- Timer-Trigger für automatische Reports

## Quick Setup

### 1. SMN Topic erstellen
- SMN → Create Topic → `resource-monitor`
- Add Subscription → Email → Ihre E-Mail
- Bestätigungs-Mail klicken

### 2. Agency erstellen
- IAM → Agencies → Create Agency
- Type: `Cloud service` → `FunctionGraph`
- Permissions hinzufügen:
  - `ECS FullAccess`
  - `RDS ReadOnlyAccess` 
  - `EVS ReadOnlyAccess`
  - `VPC ReadOnlyAccess`
  - `SMN FullAccess`

### 3. Function deployen
```bash
zip -r function.zip index.py requirements.txt src/
```

- FunctionGraph → Create Function
- Runtime: `Python 3.9`
- Handler: `index.handler`
- Agency: Die erstellte Agency
- Memory: `128 MB`
- Timeout: `30s`
- ZIP hochladen

### 4. Environment Variable
- `SMN_TOPIC_URN`: urn:smn:eu-de:PROJECT_ID:resource-monitor

### 5. Timer (optional)
- Triggers → Timer → `0 8 * * *` (täglich 8 Uhr)
