# OTC Resource Monitor - Deployment Guide

## Übersicht
Der OTC Resource Monitor ist eine FunctionGraph-Function, die alle Ressourcen in Ihrer OTC Domain überwacht und einen detaillierten Report per E-Mail versendet. Der Report versucht für jede Ressource den Creator zu ermitteln (über Tags, Metadata oder CTS).

**Wichtig für Creator-Information**: Damit die Creator-Information angezeigt wird, sollten Ressourcen mit Tags versehen werden:
- Tag-Key: `owner`, `creator`, `created_by` oder `user`
- Tag-Value: Username oder E-Mail des Erstellers

## Unterstützte Ressourcen
- **ECS Instances** (Elastic Cloud Server)
- **RDS Instances** (Relational Database Service)
- **OBS Buckets** (Object Storage Service)
- **EVS Volumes** (Elastic Volume Service)
- **VPCs** (Virtual Private Cloud)
- **Subnets**

## Voraussetzungen

### 1. SMN Topic erstellen (für E-Mail-Benachrichtigungen)
1. Navigieren Sie zu **SMN → Topics**
2. Klicken Sie auf **Create Topic**
3. Konfigurieren Sie:
   - **Topic Name**: `resource-monitor-alerts`
   - **Display Name**: `OTC Resource Monitor`

4. Subscription hinzufügen:
   - Klicken Sie auf den Topic
   - **Add Subscription**
   - **Protocol**: `Email`
   - **Endpoint**: Ihre E-Mail-Adresse
   - Bestätigen Sie die Subscription über die Bestätigungs-E-Mail

5. Notieren Sie sich die **Topic URN** (Format: `urn:smn:eu-de:PROJECT_ID:resource-monitor-alerts`)

### 2. Agency für FunctionGraph erstellen
Die Function benötigt eine Agency mit den notwendigen Permissions:

1. Navigieren Sie zu **IAM → Agencies**
2. Klicken Sie auf **Create Agency**
3. Konfigurieren Sie:
   - **Agency Name**: `ResourceMonitorAgency`
   - **Agency Type**: `Cloud service`
   - **Cloud Service**: `FunctionGraph`
   - **Validity Period**: `Permanent`
   - **Description**: Agency für Resource Monitor

4. Permissions zuweisen - fügen Sie folgende Policies hinzu:
   - `ECS FullAccess` - für ECS Instance Abfragen
   - `RDS ReadOnlyAccess` - für RDS Instance Abfragen
   - `OBS ReadOnlyAccess` - für OBS Bucket Abfragen
   - `EVS ReadOnlyAccess` - für EVS Volume Abfragen
   - `VPC ReadOnlyAccess` - für VPC/Subnet Abfragen
   - `CTS ReadOnlyAccess` - für User/Creator Informationen
   - `SMN FullAccess` - für E-Mail-Versand

## Deployment

### 1. Function Package vorbereiten
```bash
# ZIP-Archiv mit allen Dateien erstellen
zip -r resource-monitor.zip index.py requirements.txt src/
```

### 2. FunctionGraph Function erstellen

1. Navigieren Sie zu **FunctionGraph → Functions**
2. Klicken Sie auf **Create Function**
3. Wählen Sie **Create from scratch**
4. Konfigurieren Sie:
   - **Function Name**: `resource-monitor`
   - **Runtime**: `Python 3.9` oder `Python 3.10`
   - **Handler**: `index.handler`
   - **Code Entry Mode**: `Upload ZIP`
   - **Agency**: `ResourceMonitorAgency` (die zuvor erstellte Agency auswählen)

### 3. Function konfigurieren
1. **Basic Settings**:
   - **Memory**: `512 MB` (oder mehr bei vielen Ressourcen)
   - **Execution Timeout**: `300` Sekunden (5 Minuten)
   - **Concurrency**: `1`

2. **Environment Variables** - nur EINE Variable nötig:
   - **SMN_TOPIC_URN**: Die URN des SMN Topics (z.B. `urn:smn:eu-de:PROJECT_ID:resource-monitor-alerts`)

### 4. Code hochladen
1. Klicken Sie auf **Upload** im Code-Bereich
2. Wählen Sie die `resource-monitor.zip` Datei
3. Klicken Sie auf **Deploy**

### 5. Timer Trigger einrichten (für automatische Reports)
Für regelmäßige automatische Reports:

1. In der Function, navigieren Sie zu **Triggers**
2. Klicken Sie auf **Create Trigger**
3. Wählen Sie **Timer**
4. Konfigurieren Sie:
   - **Trigger Name**: `daily-resource-report`
   - **Timer Type**: Wählen Sie eine Option:
     - **Fixed Rate**: z.B. `1d` für täglich
     - **Cron Expression**: z.B. `0 8 * * *` für täglich um 8:00 Uhr
   - **Enable Trigger**: `Yes`

## Test der Function

### Manueller Test
1. In der Function-Übersicht, klicken Sie auf **Test**
2. Test Event kann leer sein: `{}`
3. Klicken Sie auf **Create and Test**
4. Prüfen Sie:
   - Die Execution Logs
   - Ihre E-Mail für den Report

### Erwartete Ausgabe bei Erfolg
```json
{
  "statusCode": 200,
  "message": "Resource report sent successfully!",
  "resources_found": {
    "ecs": 5,
    "rds": 2,
    "obs": 10,
    "evs": 8,
    "vpc": 3,
    "subnet": 12
  },
  "total_resources": 40
}
```

## Fehlerbehebung

### Häufige Probleme und Lösungen

1. **"FunctionGraph context is required"**
   - Die Function wird lokal statt in FunctionGraph ausgeführt
   - Stellen Sie sicher, dass Sie die Function in FunctionGraph testen

2. **"Could not obtain FunctionGraph token"**
   - Überprüfen Sie, ob die Agency korrekt zugewiesen ist
   - Prüfen Sie die Agency-Permissions

3. **"SMN_TOPIC_URN environment variable required"**
   - Die Environment Variable wurde nicht gesetzt
   - Fügen Sie SMN_TOPIC_URN in den Function Settings hinzu

4. **E-Mail wird nicht empfangen**
   - Prüfen Sie, ob die SMN Subscription bestätigt wurde
   - Überprüfen Sie die SMN Topic URN
   - Schauen Sie im Spam-Ordner nach

5. **Timeout Error**
   - Erhöhen Sie das Timeout (max. 900 Sekunden)
   - Prüfen Sie die Netzwerkverbindungen

### Logs prüfen
1. Navigieren Sie zu **FunctionGraph → Functions → [Ihre Function]**
2. Klicken Sie auf **Logs**
3. Wählen Sie den gewünschten Zeitraum
4. Prüfen Sie die Execution Logs für Details

## Sicherheitshinweise

1. **Principle of Least Privilege**: Die Agency hat nur Read-Permissions (außer für SMN)
2. **Token-Sicherheit**: Tokens werden automatisch von FunctionGraph verwaltet
3. **Datenschutz**: Der E-Mail-Report kann sensitive Informationen enthalten
4. **Audit Trail**: Alle Function-Ausführungen werden automatisch geloggt

## Anpassungen

### Weitere Services hinzufügen
Um weitere OTC-Services zu monitoren:

1. Erstellen Sie eine neue Datei in `src/` (z.B. `src/cce.py`)
2. Implementieren Sie die Abfrage-Funktion
3. Importieren Sie die Funktion in `index.py`
4. Fügen Sie den Aufruf in der `handler()` Funktion hinzu
5. Erweitern Sie `src/report.py` für die Darstellung

### Report-Format anpassen
Modifizieren Sie `src/report.py`:
- HTML-Styling in der `generate_html_report()` Funktion
- Zusätzliche Informationen oder Filter hinzufügen

## Support

Bei Problemen:
1. Prüfen Sie zuerst die Function Logs
2. Verifizieren Sie die Agency-Permissions
3. Stellen Sie sicher, dass die SMN Topic URN korrekt ist
4. Kontaktieren Sie bei Bedarf den OTC Support

## Wichtige Hinweise

- **Keine lokale Ausführung**: Die Function nutzt FunctionGraph-Context und kann nur dort ausgeführt werden
- **Automatische Authentifizierung**: Project ID, Domain ID und Token werden automatisch vom FunctionGraph Context bereitgestellt
- **Minimale Konfiguration**: Sie müssen nur die SMN_TOPIC_URN als Environment Variable setzen

## Versionierung

- **v2.0.0**: Vereinfachte Version
  - Nutzt nur FunctionGraph Token mit Agency
  - Automatische Project/Domain ID Erkennung
  - Nur eine Environment Variable nötig (SMN_TOPIC_URN)
  - Modulare Struktur für bessere Wartbarkeit