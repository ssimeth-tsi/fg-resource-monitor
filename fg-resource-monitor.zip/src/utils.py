import requests
import time

CTS_TRACE_URL = "https://cts.eu-de.otc.t-systems.com/v3/{project_id}/traces"


def get_resource_creator(resource_id, resource_type, token, project_id):
    """
    Versucht den Ersteller einer Resource über CTS (Cloud Trace Service) zu ermitteln
    Nutzt POST API mit besserem Filtering
    """
    try:
        headers = {
            "X-Auth-Token": token,
            "Content-Type": "application/json"
        }
        
        # Zeitfenster: letzte 30 Tage
        now_ms = int(time.time() * 1000)
        thirty_days_ms = 30 * 24 * 3600 * 1000
        start_time = now_ms - thirty_days_ms
        
        # CTS POST body für bessere Filterung
        body = {
            "trace_type": "system",
            "from": start_time,
            "to": now_ms,
            "limit": 100,
            "resource_id": resource_id
        }
        
        response = requests.post(
            CTS_TRACE_URL.format(project_id=project_id),
            headers=headers,
            json=body,
            timeout=15
        )
        
        if response.status_code == 200:
            traces = response.json().get("traces", [])
            
            # Suche nach Create-Events
            for trace in traces:
                event_name = (trace.get("event_name") or "").lower()
                trace_name = (trace.get("trace_name") or "").lower()
                
                # Check für verschiedene Create-Patterns
                create_patterns = ["create", "add", "launch", "provision", "runinstance", "createserver"]
                if any(pattern in event_name for pattern in create_patterns) or \
                   any(pattern in trace_name for pattern in create_patterns):
                    
                    user_info = trace.get("user", {})
                    # Versuche verschiedene Felder für den User
                    user_name = (
                        user_info.get("name") or 
                        user_info.get("user_name") or 
                        user_info.get("id") or
                        user_info.get("domain", {}).get("name")
                    )
                    
                    if user_name and user_name != "Unknown":
                        return user_name
            
            # Fallback: Nimm den ältesten Event für diese Resource
            if traces:
                oldest_trace = traces[-1]  # CTS gibt normalerweise neueste zuerst
                user_info = oldest_trace.get("user", {})
                user_name = (
                    user_info.get("name") or 
                    user_info.get("user_name") or 
                    user_info.get("id")
                )
                if user_name:
                    return user_name
        
        return "Unknown"
        
    except Exception as e:
        print(f"⚠️ CTS lookup failed for {resource_id}: {str(e)}")
        return "Unknown"


def extract_creator_from_metadata(metadata):
    """
    Extract creator information from resource metadata
    """
    if not metadata:
        return None
    
    # Erweiterte Liste von möglichen Creator-Feldern (basierend auf OTC Standards)
    creator_fields = [
        "creator", "Creator", "CREATOR",
        "created_by", "Created_By", "CreatedBy", "CREATED_BY",
        "user_id", "User_Id", "USER_ID",
        "op_svc_user", "Op_Svc_User",
        "owner", "Owner", "OWNER",
        "user", "User", "USER",
        "author", "Author", "AUTHOR",
        "X-OTC-Creator"
    ]
    
    for field in creator_fields:
        if field in metadata:
            value = metadata.get(field)
            if value and value != "Unknown":
                return value
    
    return None


def extract_creator_from_tags(tags):
    """
    Extract creator information from resource tags
    """
    if not tags:
        return None
    
    # Tags can be a list of dicts or a dict
    if isinstance(tags, dict):
        return extract_creator_from_metadata(tags)
    
    if isinstance(tags, list):
        for tag in tags:
            if isinstance(tag, dict):
                # Check for key-value pairs
                key = (tag.get("key") or "").lower()
                if key in ["owner", "creator", "created_by", "user", "author", "user_id"]:
                    value = tag.get("value")
                    if value and value != "Unknown":
                        return value
    
    return None


def get_server_detail(project_id, server_id, token):
    """
    Get detailed information about a specific ECS server
    """
    url = f"https://ecs.eu-de.otc.t-systems.com/v2/{project_id}/servers/{server_id}"
    headers = {"X-Auth-Token": token}
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            return response.json().get("server", {})
    except Exception as e:
        print(f"⚠️ Failed to get server detail for {server_id}: {str(e)}")
    
    return {}