"""
IAM module for resolving user IDs to readable names
"""
import requests

# Cache für User-Namen um wiederholte API-Calls zu vermeiden
_USER_NAME_CACHE = {}


def resolve_user_id_to_name(user_id, token):
    """
    Löst eine IAM User-ID in einen lesbaren Namen auf
    
    Args:
        user_id: Die User-ID die aufgelöst werden soll
        token: Authentication token
    
    Returns:
        str: Der Username oder die Original-ID falls nicht auflösbar
    """
    if not user_id or user_id == "Unknown":
        return user_id
    
    # Check cache first
    if user_id in _USER_NAME_CACHE:
        return _USER_NAME_CACHE[user_id]
    
    # Skip if already looks like a username (not a UUID)
    if "@" in user_id or "." in user_id or " " in user_id:
        return user_id
    
    # Check if it's a valid UUID format (32 or 36 chars)
    clean_id = user_id.replace("-", "")
    if len(clean_id) != 32:
        # Not a UUID, might already be a name
        return user_id
    
    headers = {"X-Auth-Token": token}
    
    # Try OS-USER endpoint (meist verfügbar mit Project-Token)
    url_os_user = f"https://iam.eu-de.otc.t-systems.com/v3.0/OS-USER/users/{user_id}"
    try:
        resp = requests.get(url_os_user, headers=headers, timeout=10)
        if resp.status_code == 200:
            user_data = resp.json()
            user = user_data.get("user", {})
            name = user.get("name") or user.get("user_name") or user.get("email") or user.get("display_name")
            if name and name != user_id:
                _USER_NAME_CACHE[user_id] = name
                print(f"  → Resolved user {user_id[:8]}... to {name}")
                return name
    except Exception:
        pass
    
    # Try standard Keystone v3 endpoint
    url_v3 = f"https://iam.eu-de.otc.t-systems.com/v3/users/{user_id}"
    try:
        resp = requests.get(url_v3, headers=headers, timeout=10)
        if resp.status_code == 200:
            user_data = resp.json()
            user = user_data.get("user", {})
            name = user.get("name") or user.get("user_name") or user.get("email") or user.get("display_name")
            if name and name != user_id:
                _USER_NAME_CACHE[user_id] = name
                print(f"  → Resolved user {user_id[:8]}... to {name}")
                return name
    except Exception:
        pass
    
    # User not found or no access - return a shortened version for readability
    # Cache the result to avoid repeated lookups
    short_id = f"User-{user_id[:8]}"
    _USER_NAME_CACHE[user_id] = short_id
    return short_id


def resolve_creator_name(creator, token):
    """
    Versucht einen Creator (ID oder Name) in einen lesbaren Namen aufzulösen
    
    Args:
        creator: Creator string (könnte ID oder bereits ein Name sein)
        token: Authentication token
        
    Returns:
        str: Aufgelöster Name oder formatierte ID
    """
    if not creator or creator == "Unknown":
        return creator
    
    # Wenn es wie eine UUID aussieht (32 hex chars), versuche aufzulösen
    clean_creator = creator.replace("-", "")
    if len(clean_creator) == 32 and all(c in '0123456789abcdefABCDEF' for c in clean_creator):
        resolved = resolve_user_id_to_name(creator, token)
        return resolved if resolved else creator
    
    return creator